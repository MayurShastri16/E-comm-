const express=require('express')
const path=require('path')
// const hbs=require('hbs')
const bodyparser=require('body-parser')
const hbs=require('express-handlebars')
const mysql=require('mysql');
const session=require('express-session')

var app=express()
//configure view engine as hbs
app.set('views',path.join(__dirname,'views'))
app.set('view engine','hbs')
//congigure express handlebars
app.engine('hbs',hbs({
  extname: 'hbs',
  defaultLayout: 'mainLayout',
  layoutsDir:__dirname+'/views/layouts/'
}));


//sql
var con=mysql.createConnection({
  user:'root',
  password:'root',
  port:3306,
  host:'localhost',
  database:'server'
})

app.use(session({secret:'asdfsaad'}))
app.listen(3000,()=>{
  console.log("server started on port:3000");
})
//configure body bodyparser
app.use(bodyparser.json())//enable to transfer data
app.use(bodyparser.urlencoded({
  extended:true
}))//unlimited length of data


app.get('/',(req,res)=>{
  res.render('customerLogin')
})

app.get('/admin',(req,res)=>{
  res.render('login')
})

app.get('/newuser',(req,res)=>{
  res.render('newuser')
})


app.get('/forgotpassword',(req,res)=>{
  res.render('forgotpassword')
})

app.post('/createnewuser',(req,res)=>{
  var name=req.body.name;
  var email=req.body.email;
  var username=req.body.username;
  var password=req.body.password;
  var sql2="insert into user(name,email,username,password)values(?,?,?,?) "
  var values=[name,email,username,password]
  sql2=mysql.format(sql2,values)
  con.query(sql2,(err,result)=>{
    if (err) throw err;
    else
    res.render('newuser',{msg:"Account created sucessfully"})


  })
})

app.post('/logincheck',(request,response)=>{
	var email=request.body.username;
	var password=request.body.password;
  var sql="select * from user where email=? and password=?"
  var values=[email,password]
  sql=mysql.format(sql,values)
  con.query(sql,(err,result)=>{
    if(err) throw err;
    else if(result.length>0){
      request.session.user=email
    response.render('home',{data:result,admin:request.session.user})
  }
  else{
    response.render("login",{msg:"login fail"})
  }
  })
})


app.post('/customerLoginCheck',(request,response)=>{
	var email=request.body.username;
	var password=request.body.password;
  var sql="select * from customer where email=? and password=?"
  var values=[email,password]
  sql=mysql.format(sql,values)
  con.query(sql,(err,result)=>{
    if(err) throw err;
    else if(result.length>0){
    response.render('home',{data:result})
  }
  else
  response.render("customerLogin",{msg:'login fail'})
  })
})
app.get('/logout',(req,res)=>{
  req.session.destroy();
  res.render('CustomerLogin',{msg:'Logout successfully'})
  
  })

app.get('/home',(req,res)=>{
  res.render('home',{admin:req.session.user})
})

app.get('/AddCustomer',(req,res)=>{
  res.render('AddCustomer',{admin:req.session.user})
})

app.get('/CreatePlan',(req,res)=>{
  res.render('CreatePlan',{admin:req.session.user})
})


app.get('/CreateAccount',(req,res)=>{
  var sql="select * from customer"
  

  con.query(sql,(err,result)=>{
    if(err) throw err;
 
    else{
  var customer=result;
  var sql2="select * from plans"
  

  con.query(sql2,(err,result)=>{
    if(err) throw err;
 
    else{
      var plan=result;
  res.render('AddAccount',{plan:plan,customer:customer,admin:req.session.user})
    
    }
  })
}
})
})
//add plan

app.post('/AddPlan',(request,response)=>{
	var PlanName=request.body.planname;
  var TimePeriod=request.body.TimePeriod;
  var Charges=request.body.charges;
  var sql2="insert into plans(plan_name,Time_period,charges)values(?,?,?) "
  var values=[PlanName,TimePeriod,Charges]
  sql2=mysql.format(sql2,values)
  con.query(sql2,(err,result)=>{
    if(err) throw err;
    else
    response.render('CreatePlan',{msg:"Plan Added sucessfully",admin:request.session.user})
  })
})


app.get('/ViewPlan',(request,response)=>{

  var sql="select * from plans"

  con.query(sql,(err,result)=>{
    if(err) throw err;
 
    else
    console.log(result)
    response.render('ViewPlan',{data:result,admin:request.session.user})
  })
}
 
)


app.get('/deletePlan',(req,res)=>{
  var id=req.query.id;
  
  var sql="delete from plans where id=?"
  value=[id]
  sql=mysql.format(sql,value)
  con.query(sql,(err,result)=>{
  if(err) throw err;
  else if(result.affectedRows!=0)
  {
    var sql='select * from plans';
    con.query(sql,(err,result)=>{
    if(err) throw err;
    else
      res.render('ViewPlan',{data:result,msg:'Data Deleted',admin:req.session.user})
    })
  }
  })
  
  })

  app.get('/updatePlan',(req,res)=>{
    var id=req.query.id;
    
    var sql="select * from plans where id=?"
    value=[id]
    sql=mysql.format(sql,value)
    con.query(sql,(err,result)=>{
    if(err) throw err;
    else 
    {
     
        res.render('UpdatePlan',{data:result[0],msg:'Data Deleted',admin:req.session.user})
      }
    })
  })




  
app.post('/newCustomer',(request,response)=>{
	var Name=request.body.name;
  var Mobile=request.body.mobile;
  var Email=request.body.email;
  var password=request.body.password;
  var sql2="insert into customer(name,mobile,email,password)values(?,?,?,?) "
  var values=[Name,Mobile,Email,password]
  sql2=mysql.format(sql2,values)
  con.query(sql2,(err,result)=>{
    if(err) throw err;
    else
    response.render('AddCustomer',{msg:"Customer Added sucessfully",admin:request.session.user})
  })
})

app.get('/ViewCustomer',(request,response)=>{

  var sql="select * from customer"

  con.query(sql,(err,result)=>{
    if(err) throw err;
 
    else
    console.log(result)
    response.render('ViewCustomer',{data:result,admin:request.session.user})
  })
}
)


app.post('/createnewaccount',(request,response)=>{
	var Name=request.body.name;
  var DomainName=request.body.domainname;
  
  var Plan=request.body.plan;
  var Domain=request.body.radio;
  var Registration=request.body.Registration;
  var TimePeriod=request.body.TimePeriod;
  var Expiry=request.body.Expiry;
  var Hosting=request.body.hosting;
  var DomainCharge=request.body.domaincharge;
  var Total=request.body.total;
  
  var sql2="insert into account(name,domain_name,plan,domain,registration,time_period,expiry,domain_charge,hosting,total)values(?,?,?,?,?,?,?,?,?,?) "
  var values=[Name,DomainName,Plan,Domain,Registration,TimePeriod,Expiry,DomainCharge,Hosting,Total]
  sql2=mysql.format(sql2,values)
  con.query(sql2,(err,result)=>{
    if(err) throw err;
    else
    response.render('AddAccount',{msg:"Account Created sucessfully",admin:request.session.user})
  })
})



app.get('/ViewAccount',(request,response)=>{

  var sql="select * from account"

  con.query(sql,(err,result)=>{
    if(err) throw err;
 
    else
    
    response.render('ViewAccount',{data:result,admin:request.session.user})
  })
}
 
)
app.get('/checkfilter', (req, res) => {
  // const val=req.query.search;
  // console.log(val);

  let text = req.query.text + "%"
  console.log(text);
  let filter = req.query.filter
  console.log(filter);
  let sql = "select * from account";
  if (text) {
      sql = "select * from account where name like?";

  }

  if (filter) {
      if (filter == 'upcoming expiry') {
          sql = 'select * from account where expiry between curdate() and expiry';

      }
      else if (filter == 'current month expiry') {
          sql = 'SELECT *FROM account WHERE MONTH(expiry) = MONTH(CURRENT_DATE()) AND YEAR(expiry) = YEAR(CURRENT_DATE())';
      } else
          sql = "select * from account";
  }

  let values = [text]
  sql = mysql.format(sql, values)
  con.query(sql, (err, result) => {
      console.log(sql);
      if (err)
          throw err;
      else if (result.length != 0) {
          res.json({ data: result, msg: "data Found" });
      }
      else {
          console.log(" data not exist");
          res.json({ msg: 'not found' });
      }
  })

})



app.get('/deleteCustomer',(req,res)=>{
  var id=req.query.id;
  
  var sql="delete from customer where id=?"
  value=[id]
  sql=mysql.format(sql,value)
  con.query(sql,(err,result)=>{
  if(err) throw err;
  else if(result.affectedRows!=0)
  {
    var sql='select * from customer';
    con.query(sql,(err,result)=>{
    if(err) throw err;
    else
      res.render('ViewCustomer',{data:result,msg:'Data Deleted',admin:req.session.user})
    })
  }
  })
  
  })
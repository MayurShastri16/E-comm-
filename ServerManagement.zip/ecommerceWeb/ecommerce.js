const express=require('express')
const path=require('path')
const hbs=require('express-handlebars')
const bodyparser=require('body-parser')
const session=require('express-session')
const upload=require('express-fileupload')
//Express app creation
var app=express();
//config viewengine on hbs
app.set('views',path.join(__dirname,'views'))
app.set('view engine','hbs')

//server creation

app.engine('hbs',hbs({
  extname: 'hbs',
  defaultLayout: 'mainlayouts',
  layoutDir:__dirname+'/views/layouts'
}));

app.use(express.static(path.join(__dirname,'views')))


app.use(session({secret:'asdfsaad'}))
app.listen(3000,()=>{
  console.log("server started on port:3000");
})
app.use(bodyparser.json())
app.use(bodyparser.urlencoded({
  extended:true
}))
app.get('/',(req,res)=>{
  var Product=require('./models/product')
  Product.find({},(err,result)=>{
    if(err)
    throw err;
    else
    res.render('home',{data:result})
})
})
app.get('/home',(req,res)=>{
  var Product=require('./models/product')
  Product.find({},(err,result)=>{
    if(err)
    throw err;
    else
    res.render('home',{data:result,admin:req.session.user,subadmin:req.session.user})
})
})


app.get('/adminlogin',(req,res)=>{
  res.render('adminlogin')
})

app.get('/slogin',(req,res)=>{
  res.render('slogin')
})
app.get('/logout',(req,res)=>{
req.session.destroy();
res.render('index',{msg:'Logout successfully'})

})
const mongoose=require('mongoose')
const URL="mongodb://localhost:27017/ecom";
mongoose.connect(URL)

var Login=require('./models/login')
app.post('/logincheck',(req,res)=>{
  var userid=req.body.logid;
  var passwd=req.body.pwd;
  Login.find({uid:userid,password:passwd},(err,result)=>{
    if (err) throw err;
    else if(result.length!=0){
      req.session.user=userid
      Product.find({},(err,result)=>{
        if(err)
        throw err;
        else{
    res.render('home',{data:result,admin:req.session.user})
  }
})
}
    else {
      res.render('adminlogin',{msg:'login Fail'})
    }
  })
})
// app.get('/insert',(req,res)=>{
//   var newdata=Login({
//     uid:'patel7293@gmail.com',
//     password:'admin123'
//   })
//    newdata.save()
//  })
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: '29abhishek.p@gmail.com',
    pass: 'abhishek@29'
  }
});


app.get('/sadminlogin',(req,res)=>{
  res.render('sadminlogin')
})
//------create subAdmin-----------
const Subadmin=require('./models/subadmin')
app.post('/sadminlogin',(req,res)=>{
  var id=req.body.id;
  var passwd=req.body.pwd;
  var newuser=Subadmin({
  uid:id,
  password:passwd
})
newuser.save().then((data)=>{
var mailOptions = {
    from: '29abhishek.p@gmail.com',
    to: id,
    subject: 'Subadmin Password',
    text: 'Hello '+id+" , your passwword is "+passwd
  };
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    }
     else {
res.render('sadminlogin',{msg:'Password is sent on your mail id',admin:req.session.user})
     // console.log('Email sent: ' + info.response);
    }
  });
})
})

//-------subadmin login-----------------
app.post('/slogincheck',(req,res)=>{
  var userid=req.body.uid;
  var passwd=req.body.pwd;
  Subadmin.find({uid:userid,password:passwd},(err,result)=>{
    if (err) throw err;
    else if(result.length!=0){
    req.session.users=userid
    res.render('home',{data:result,subadmin:req.session.users})
  }
    else {
      res.render('slogin',{msg:'login Fail'})
    }
  })
})



app.get('/adminhome',(req,res)=>{
  Subadmin.find({},(err,result)=>{
 if(err)
throw err;
   else{
     console.log(result);
  res.render('adminhome',{data:result,admin:req.session.user})
}
})
})
app.use(upload())
app.get('/addproduct',(req,res)=>{
  res.render('addproduct',{admin:req.session.user})
})


var Product=require('./models/product')
app.post('/uploadAction',(req,res)=>{
  console.log(req.files)
  if(req.files)
  {
    var productname=req.body.pname;
    var file=req.files.imagename;
    var imgname=file.name;
    var category=req.body.option;
    var price=req.body.price
    var discription=req.body.discription;
    var newimgname=Math.floor(Math.random()*1000000)+imgname;
    file.mv('./upload/'+newimgname,(err,result)=>{
      if(err) throw err;
      else{
        var newdata=Product({
          pname:productname,
          imgname:newimgname,
          category:category,
          price:price,
          discription:discription
        })
        newdata.save().then((data)=>{
          res.render('addproduct',{msg:'File Uploaded',admin:req.session.user,subadmin:req.session.user})
        })
      }
    })

  }
})
//--------view products-----------

app.use(express.static('upload'))
app.get('/viewproducts',(req,res)=>{
Product.find({},(err,result)=>{
  if(err)
  throw err;
  else {
    res.render('viewproducts',{data:result,admin:req.session.user})
  }
})
})
//-------delete sub admin--------------
app.get('/delete',(req,res)=>{
  var id=req.query.uid;
  console.log(id);
  Subadmin.remove({uid:id},(err,result)=>{
    if (err)
    throw err;
    else
  if(result.affectedRows!=0){
    Subadmin.find({},(err,result)=>{
   if(err)
  throw err;
     else
      res.render('adminhome',{data:result,admin:req.session.user,msg:'Data Deleted'})
  })
}
  })
})

//---------------ajax

app.get('/checkmail',(req,res)=>{
      var sb=req.query.email;
      Subadmin.find({uid:sb},(err,result)=>{
                if(err) throw err;
                else if(result.length!=0)
                  {   console.log("Email_id " +sb+ " Exist");
                      res.json({'msg':'Email_id ' +sb+ ' already Exist'})
                  }
                else
                   {   console.log("Email_id " +sb+ " Not Exist");
                        res.json({'msg':' Available '})
                    }
         })
    })

//forgot password
    app.get('/forgotpwd',(req,res)=>{
      res.render('forgotpwd')
    })

    app.post('/forgotpwd',(req,res)=>{
  var email=req.body.logid;
  Login.find({uid:email},(err,result)=>{
    if(err)throw err;
    else {
      var mailOptions = {
          from: '29abhishek.p@gmail.com',
          to: email,
          subject: 'Admin Password',
          text: 'Hello Admin '+email+" \n your passwword is "+result[0].password
        };
        transporter.sendMail(mailOptions, function(error, info){
          if (error) {
            console.log(error);
          }
           else {
      res.render('forgotpwd',{msg:'Password is sent on your mail id'})
           // console.log('Email sent: ' + info.response);
          }

  })
}
})
})

//---------------------------------update product---------------------------



var ObjectID = require('mongodb').ObjectID;
app.get('/upProduct',(req,res)=>{
var pid=req.query.id
Product.findOne({"_id": new ObjectID(pid)},(err,result)=>{
if(err) throw err;
else {
  console.log(result);
  res.render('update',{data:result})
}
})
})
const fs=require('fs')

app.post('/updateproductAction',(req,res)=>{
  var pid=req.body.pid
   var productname=req.body.pname;
   var category=req.body.option;
   var price=req.body.price
   var discription=req.body.discription;
  if(req.files)
  {
    Product.find({_id:pid},(err,result)=>{
if (err) throw err;
  else
{console.log("-------------------------");
  console.log(result);
  fs.unlink('upload/'+result[0].imgname,(err)=>{if(err) throw err;});
}
    })




    console.log("if block executed...");
     var file=req.files.imagename;
     var imgname=file.name;
     var newimgname=Math.floor(Math.random() * 1000000)+imgname;
     file.mv('./upload/'+newimgname,(err,result)=>{
     if(err) throw err;
     else
    {
    //update code
Product.update({"_id": new ObjectID(pid)},{$set:{pname:productname,imgname:newimgname,category:category,price:price,discription:discription}},(err,result)=>{
   if(err) throw err;
   else
  {
  console.log("Updated");
  Product.find((err,result)=>{
    if(err) throw err;
    res.render('viewproducts',{data:result,msg:'updated'})
  })
}
  })
   }
   })
 }else{
   console.log("else block executed...");
   Product.update({"_id": new ObjectID(pid)},{$set:{pname:productname,category:category,price:price,discription:discription}},(err,result)=>{
      if(err) throw err;
      else
{          console.log("Updated");
          Product.find((err,result)=>{
            if(err) throw err;
            res.render('viewproducts',{data:result,msg:'updated'})
          })
}
     })

 }

})

//------------subadmin--------
app.get('/saddproduct',(req,res)=>{
  res.render('addproduct',{subadmin:req.session.user})
})

app.get('/sviewproducts',(req,res)=>{
Product.find({},(err,result)=>{
  if(err)
  throw err;
  else {
    res.render('viewproducts',{data:result,subadmin:req.session.user})
  }
})
})
//------------------------delete product

app.get('/pdelete',(req,res)=>{
  var id=req.query._id;
  console.log(id);
  Product.deleteOne({_id:id},(err,result)=>{
    if (err)
    throw err;
    else
  if(result.affectedRows!=0){
    Product.find({},(err,result)=>{
   if(err)
  throw err;
     else
      res.render('viewproducts',{data:result,admin:req.session.user,subadmin:req.session.user,msg:'Data Deleted'})
  })
}
  })
})

//--------product detail----------------
app.get("/productdetails",(req,res)=>{
  var pid=req.query.pid
  Product.find({_id:pid},(err,result)=>{
    if(err)
    throw err;
    console.log(result);
    res.render('productDetail',{data:result[0]})
  })
})
//-----add to cart------
const Cart=require('./models/cart')
app.post("/cart",(req,res)=>{
  var s=req.session.userc
  if(req.session.userc==null){
      var a=ip.address();
  var quantity=req.body.quantity;
  var productid=req.body.product
  var newCart=Cart({pid: productid,
    qty:quantity,email:a})
    newCart.save().then(data=>{
      Product.find({},(err,result)=>{
        if(err)
        throw err;
        else
      res.render('home',{data:result,msg:'product added to cart'})
    })
  })
}else{
  var quantity=req.body.quantity;
  var productid=req.body.product
  var newCart=Cart({pid: productid,
    qty:quantity,email:s})
    newCart.save().then(data=>{
      Product.find({},(err,result)=>{
        if(err)
        throw err;
        else
      res.render('home',{data:result,msg:'product added to cart',customer:req.session.userc})
    })
  })
}
})
//-------customersignup--------

app.get('/customersignup',(req,res)=>{
  res.render('customersignup')
})
const Customer=require('./models/customer')
app.post('/customersignup',(req,res)=>{
  var id=req.body.id;
  var name=req.body.cname
  var mobile=req.body.mobile
  var passwd=req.body.pwd;
  var newuser=Customer({
    name:name,
    uid:id,
    mobile:mobile,
    password:passwd
})
newuser.save().then((data)=>{
var mailOptions = {
    from: '29abhishek.p@gmail.com',
    to: id,
    subject: 'Customer Password',
    text: 'Hello '+id+" , your passwword is "+passwd
  };
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    }
     else {
res.render('customersignup',{msg:'Password is sent on your mail id',admin:req.session.user})
     // console.log('Email sent: ' + info.response);
    }
  });
})
})
//--------customer Login check---------
app.get('/customerlogin',(req,res)=>{
  res.render('customerlogin')
})
app.post('/clogincheck',(req,res)=>{
  var userid=req.body.uid;
  var passwd=req.body.pwd;
  req.session.userc=userid
  Subadmin.find({uid:userid,password:passwd},(err,result)=>{
    if (err) throw err;
    else if(result.length!=0){
       Product.find({},(err,result)=>{
        if(err)
        throw err;
        else
          req.session.user=userid
      res.render('home',{data:result,msg:'login success',customer:req.session.userc})
    })

  }
    else {
      res.render('customerlogin',{msg:'login Fail'})
    }
  })
})

//code for if not login then ip address should be the user name
var ip=require("ip");

//----------view cart------------
app.get('/viewcart',(req,res)=>{
   if (req.session.userc==null)
 {
    var a=ip.address();
  Cart.aggregate(
    [
      {
        $lookup:
        {from:'products',
         localField:'pid',
        foreignField:'_id',
        as:'data'}
      },
      {
           $match:{  "email":a}
                             }
    ],(err,result)=>{
      if(err) throw err;
      console.log(result);

        var fprice=result.map((rec)=>{
       return rec.data[0].price*rec.qty;
          })
      var finaldata=result.map((rec,index)=>{
            var pair={fprice:fprice[index]};
            var objs={...rec,...pair}
            return objs;
                 })
      console.log(">>>>>>>>>"+fprice)
      var grandtotal=fprice.reduce((total,num)=>{
           return total+num
                         },0)
        console.log("Grand total="+grandtotal);
  res.render('cart',{products:finaldata,gtotal:grandtotal})
                 }
       )
  }
 else
       {
         var customer=req.session.userc;
          Cart.aggregate(
                          [{
                             $lookup:{
                                        from:"products",
                                        localField:"pid",
                                        foreignField:"_id",
                                        as:"data"
                                      }
                            },
                             {
                              $match:{  "email":customer }
                             }
            ],(err,result)=>{
                  if (err) throw err;
                  else
                    console.log(result);
                     var fprice=result.map((rec)=>{
                     return rec.data[0].price*rec.qty;
                      })
        var finaldata=result.map((rec,index)=>{
                var pair={fprice:fprice[index]};
                var objs={...rec,...pair}
                return objs;

                                   })
        console.log(">>>>>>>>>"+fprice)
  var grandtotal=fprice.reduce((total,num)=>{
              return total+num
                           },0)
        console.log("Grand total="+grandtotal);
      res.render('cart',{products:finaldata,gtotal:grandtotal})
                 }
           )
         }
    })

    //##################    DELETE FROM CART   ###############################3
app.get('/delcart',(req,res)=>{
  pid=req.query.pid
   user=req.session.userc;
  if(req.session.userc==null){
     userip=ip.address();
     Cart.deleteOne({_id:pid},(err,result)=>{
       if(err) throw err;
       else if(result.affectedRows!=0)
     {
       Cart.aggregate(
         [{
              $lookup:
                       {
                           from:"products",
                           localField:"pid",
                           foreignField:"_id",
                           as:"data"
                       }
         },{$match:{"email":userip}}
       ],(err,result)=>{
           if (err) throw err;
           console.log(result);
           var fprice=result.map((rec)=>{
          return rec.data[0].price*rec.qty;
             })
         var finaldata=result.map((rec,index)=>{
               var pair={fprice:fprice[index]};
               var objs={...rec,...pair}
               return objs;
                    })
         console.log(">>>>>>>>>"+fprice)
         var grandtotal=fprice.reduce((total,num)=>{
              return total+num
                            },0)
           console.log("Grand total="+grandtotal);
     res.render('cart',{products:finaldata,gtotal:grandtotal})
                    }
          )
        }
   })
 }

  else{
    Cart.deleteOne({_id:pid},(err,result)=>{
      if(err) throw err;
      else if(result.affectedRows!=0)
    {
      Cart.aggregate(
        [{
             $lookup:
                      {
                          from:"products",
                          localField:"pid",
                          foreignField:"_id",
                          as:"data"
                      }
        },{$match:{"email":user}}
      ],(err,result)=>{
          if (err) throw err;
          console.log(result);
          var fprice=result.map((rec)=>{
         return rec.data[0].price*rec.qty;
            })
        var finaldata=result.map((rec,index)=>{
              var pair={fprice:fprice[index]};
              var objs={...rec,...pair}
              return objs;
                   })
        console.log(">>>>>>>>>"+fprice)
        var grandtotal=fprice.reduce((total,num)=>{
             return total+num
                           },0)
          console.log("Grand total="+grandtotal);
    res.render('cart',{products:finaldata,gtotal:grandtotal})
                   }
         )
       }
  })

  }
})

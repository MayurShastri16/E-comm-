
const mongoose = require('mongoose');
const Productschema=mongoose.Schema({
  pname:String,
  imgname:String,
  category:String,
  price:Number,
  discription:String,
  updated_at:{type:Date,Default:Date.now}
})
module.exports=mongoose.model('Product',Productschema)

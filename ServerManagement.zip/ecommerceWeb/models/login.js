const mongoose=require('mongoose')
const LoginSchema=mongoose.Schema({
  uid:String,
  password:String

})
module.exports=mongoose.model('Login',LoginSchema)

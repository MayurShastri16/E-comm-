const mongoose=require('mongoose')
const SubadminSchema=mongoose.Schema({
  uid:String,
  password:String

})
module.exports=mongoose.model('subadmin',SubadminSchema)

const mongoose = require("mongoose");

const cartSchema = mongoose.Schema({
pid : { type: mongoose.Schema.ObjectId, required: true},
email : String,
qty : Number,
})
module.exports=mongoose.model('CartItems',cartSchema);

const mongoose=require('mongoose')
const CustomerSchema=mongoose.Schema({
  name:String,
  uid:String,
  mobile:Number,
  password:String

})
module.exports=mongoose.model('Customer',CustomerSchema)

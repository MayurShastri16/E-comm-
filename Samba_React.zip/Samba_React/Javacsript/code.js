var sub_one="react";
var sub_two="Angular";
var sub_three="mongo";
console.log( sub_one, sub_two, sub_three);

let name="Mayur";
let   sal="50000";
let Sqlquery=`select * from ${name} where esal> ${sal}`;
console.log( Sqlquery);

 var flag= true;
 console.log(flag);

 // take array
var arr=[
   "react","mongodb","node_js","Express_js"
];
/*for (var i=0; i<arr.length; i++){
    console.log(arr[i]);
};*/
/*arr.forEach((element,index) =>{
    console.log(element, index);
});*/
for ( var value of arr) {
    console.log( value);
};

//duplicate variable
/*var data=100;
var data=200;
console.log(data);

let data=100;
let data=200;
console.log(data);
 */

// Global  puluting with var
var data=100;
{
    var data=200; // local
}
console.log(data);

    let bata=100; //global
{
    let bata=200; //local
}
console.log(bata);

 /*---------------------------------Scope rule ----------------------------*/
/* //with var
for(var i=0; i<10; i++)
{

}
    console.log( i); //O/P 10
*/

// with let
for(let i=0;i<10;i++)
{
   /* console.log(i);  */ // 0 to 9
};
console.log(i);
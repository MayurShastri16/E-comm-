/*let fun_onw=()=>{
  return "welcome"
};
console.log(fun_onw());

let fun_one=(arg1,arg2, arg3,)=>{
  return arg1+ "  " + arg2 + "  " + arg3;
};
console.log (fun_one("react" ,"angular", "node"));

//---------------------function1 returning function2-----------


let fun_one =( )=>{
   return fun_two ();
};
let fun_two=()=>{
  return"welcome";
};
console.log( fun_one());

*/


//        pass arrow function as argument toanother arrow function


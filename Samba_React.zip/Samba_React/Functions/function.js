/*         Example :-1 calling of Function

 function fun_one(){
    return "welcome";
};
console.log(fun_one());
*/




/*         Example :-2  returning by argument
let fun_one=(arg1,arg2, arg3)=> {
    return arg1+"<.....>"+arg2+ "<....>"+arg3;
 };
console.log(fun_one("ReactJs","NodeJs","MongoDb"));
console.log(fun_one("Angular","NodeJs","MY Sql"));
console.log(fun_one("VeuJs","NodeJs","SQL Server"));
*/



/*    Example :- 3 function1 returning function2
function fun_one(){
    return fun_two();
}
function fun_two(){
    return "welcome";
}
console.log(fun_one());
*/



/*   Example:- 4    take one empty aray
let arr=[];
function fun_one() {
    return"Hello";
}
for(let i=0; i>5;i++) {
    arr.push(fun_one());
}
arr.forEach((element,index)=>{
    console.log(element,index);
}); */


/*
//                 Example :- 5

function fun_one(){
    return fun_two;
}
function fun_two() {
     return "hello Mayur";
}
console.log(fun_one()());
*/


/*
// Example : 6 Push function to Array 5 Times

let arr=[];
function fun_one() {
    return " wellcome";
}

for( let i=0; i<5; i++) {
    arr.push(fun_one);
}
for( let i=0; i<arr.length; i++) {
    console.log(arr[i]());
  */




/*
// Example :- 7 pass array to function

function fun_one(arg1 ) {
    console.log(arg1[0] , arg1[1])
}
function fun_two(){
    return "Wellcome_1"
}
function fun_three(){
    return " Wellcome_2";
}
let arr=[fun_two(),fun_three()];
fun_one(arr);
*/


/*<------------------ Anonymous Function ----------------------> */
  /*syntex:- // function definition
  var/let/const variable_name = (argument)=>{
   // business logic
   };
   // call the function
   variableName ( parameter)

   */
 /*
  example:-1  creat the arrow function  with the help of following variable
@fun_one // arrow function will return wellcome message


 let fun_one=()=>{
     return " welcome";
 }
 console.log( fun_one());

*/


 let fun_one=(arg1,arg2,arg3)=>{

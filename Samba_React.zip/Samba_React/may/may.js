 /*    function fun_one(){
     return fun_two();

};
function fun_two(){
    return "welcome";
};
console.log(fun_one());*/


function fun_three(arg1){
 console.log(arg1[0](), arg1[1]());    
};
function fun_four(){
    return "hello-1";
};
function fun_five(){
    return "hello-2";
};
let arr=[ fun_four,fun_five];
fun_one(arr);

 


/*<---------------------------------------Anonymous Function / arrow function / callback Function ------------------------------->*/
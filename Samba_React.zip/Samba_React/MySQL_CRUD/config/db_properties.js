let obj = {
    host    :   "localhost",
    user    :   "root",
    password:   "root",
    database:   "testdb"
};
module.exports = obj;